
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'craymaru',
  applicationName: 'express-sample',
  appUid: 'K3PBb4f9m5Q7gJBjmQ',
  orgUid: 'f4c88b84-8a7d-46bc-be44-4cb129fb9b2f',
  deploymentUid: 'c2a66c3d-de79-4882-86a6-754a84d113f8',
  serviceName: 'express-sample',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.2.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'express-sample-dev-app', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}